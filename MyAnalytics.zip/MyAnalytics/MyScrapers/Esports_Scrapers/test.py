import scrapy

class TestSpider(scrapy.Spider):
    name = 'test' # scraper name
    allowed_domains = ['www.reddit.com/r/gameofthrones/']
    start_urls = ['http://www.reddit.com/r/gameofthrones//']

    def parse(self, response):
        pass
