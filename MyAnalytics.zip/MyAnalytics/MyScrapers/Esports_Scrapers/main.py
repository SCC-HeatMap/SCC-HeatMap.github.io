# This is a sample Python script.
# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
# To start a scraper project us the following -> scrapy genspider test www.reddit.com/r/gameofthrones/

import bs4 from BeautifulSoup as bs



def main():
    print('Hi')  # Press Ctrl+F8 to toggle the breakpoint.


# This is runs the program when you execute python3 main.py
if __name__ == '__main__':
    main()




