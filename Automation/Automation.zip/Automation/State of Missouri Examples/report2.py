import pandas as pd
import numpy as np
from flask import *
import webbrowser
import os
import requests
import simplejson as json
from flask import jsonify
from collections import Counter
import threading

app = Flask(__name__) # See this website to get an explanation of what flask does -> https://pythonhow.com/how-a-flask-app-works/

@app.route('/')
def hello():
    # Flask will look for templates in the templates folder. So if your application is a module, this folder is next to that module, if it’s a package it’s actually inside your package:
    return render_template('test.html')


@app.route('/index')
def index():
    return render_template('index2.html')


# This creates a flask web app on the /results page.
@app.route('/result')
def result():
    results = pd.read_csv('test_set.csv', skiprows=[1, 2]) # Skips rows 2 and 3 since it is 0 indexed
    results = results.replace(np.nan, '', regex=True) # Replaces NaN with blanks
    # print(results[['feedbackMDA','feedbackDMH']])

    # Clean the columns so that they only have the format FIRST LAST

    # Concat the two columns
    results['feedback'] = results[['feedbackMDA', 'feedbackDMH']].apply(lambda x: ''.join(x), axis=1) # Concats these two columns into one. This gives you a full list of people that recieved feedback

    group = 'DMH' # creates a string with value 'MDA'
    Filtered_group = 'feedback' + group # creates a string with value 'feedbackMDA'
    Feedback_group = 'division' + group # creates a string with value 'divisionMDA'
    names = results[Filtered_group].unique() # creates a DF of people that were only in the feedbackMDA column
    print(names) # Prints out all the columns in the full DF

    # Creates a python list named scoring that will hold all the data/stats we calculate for each person rated
    scoring = []

    # Goes through the names list if their name shows up more than 3 times than we run their stats through the analysis
    for name in names[0:3]:
        if len(results[results['feedback'] == name]) > 0: #This function only runs the analysis if the person's name shows up 4 or more times
            name1 = {} # creates a dictionary data structure
            # print(name+":"+str(len(results[results['feedback']==name])))
            name1['name'] = name # Sets the dictionary token "name" and gives it the value stored in name

            division = results[Feedback_group][results['feedback'] == name].iloc[0] # This code looks for the division column; Then parses this down further by looking for the rows that have the name you are looking for; Finally, it take the division of the first value that matches
            name1['division'] = division # Sets the dictionary token "division" and gives it the value stored in the above variable

            department = results['department'][results['feedback'] == name].iloc[0]
            name1['department'] = department

            role = results['role' + group][results['feedback'] == name].iloc[0] #
            name1['role'] = role

            facility = results['facility' + group][results['feedback'] == name].iloc[0]
            name1['facility'] = facility

            shift = results['shift'][results['feedback'] == name].iloc[0]
            name1['shift'] = shift

            name1['countofresponse'] = results[results['feedback'] == name].shape[0] # number of responses (rows) the person had
            print(type(results[results['feedback'] == name].shape[0]))

            comments = results['comments'][results['feedback'] == name] # This saves the person's comments that they got
            name1['comments'] = (list(filter(None, comments.tolist()))) # This filters the comments a person receives into a list then saves that list to the dictionary token "comments"

            overall = {'Sometimes': 0, 'Often': 0, 'Always': 0, 'Rarely': 0, 'Never': 0} # Creates a dictionary named overall and gives it token: values.
            score = results[['Core_Questions_1', 'Core_Questions_2',
                             'Core_Questions_3', 'Core_Questions_4', 'Core_Questions_5',
                             'Core_Questions_6']][results['feedback'] == name] # This saves the scores the person got for the following core questions in the variable score

            for item in score.columns:
                try:
                    overall = Counter(score[item].value_counts().to_dict()) + Counter(overall) # This counts the amount of times they received a specific rating and adds it to the running overall counter. Since a Counter is really just a dictionary you have to do some weird stuff to get it to work.
                except:
                    overall = Counter(score[item].value_counts().to_dict()) # This shouldnt be used but I have it written just in case
                name1.update({str(item): score[item].value_counts(normalize=True).to_dict()}) # Updates the dictionary to have a column that has the tallied dictionary for the individual question
            print(overall)

            overall = dict(overall) # Changes the overall from a Counter to a dictionary. Counter is a dictionary but a subclass. This just generalizes the data type for semantic reasons.
            name1['score'] = overall # It adds the to the person's running dictionary
            try:
                Always = overall['Always'] # Counts the number of Always responses the person got
            except:
                Always = 0 # If there isn't a value then it will return 0 by default
            try:
                Often = overall['Often']
            except:
                Often = 0

            name1['favScore'] = (Always + Often) / sum(overall.values()) # Creates a percentage of favorability (total always + total often divided by the number of total responses received) this is saved in their dict as favScore
            s = sum(overall.values()) # This sums all the values in the dictionary across all the tokens
            item_score = {} # creates a new dictionary called item_score
            for k, v in overall.items(): # .items() returns a list of tuples in the form of (token, value).
                pct = v * 100.0 / s # Turns the value into a percentage for the specific response value
                item_score[k] = pct # saves this into the dictionary made above in the form of (Always: XX%, Often: XX%...)
            name1['item_score'] = item_score # adds the item score to the person's data dictionary

            scoring.append(name1) #Adds everything we just did the specific person to the scoring list before moving onto the next person in the loop

    print(scoring)
    return render_template('result.html', result=scoring)


@app.route('/<name>')
def hello_name(name):
    return "Hello {}!".format(name)

if __name__ == '__main__':
    """  https://github.com/r0x0r/pywebview/blob/master/examples/http_server.py
    """
    webbrowser.open_new("http://127.0.0.1:5000/result")
    app.run()
    #
    # t = threading.Thread(target=start_server)
    # t.daemon = True
    # t.start()
