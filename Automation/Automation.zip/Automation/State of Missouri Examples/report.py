import pandas as pd
import numpy as np
from flask import *
import webbrowser
import os
import requests
import simplejson as json
from flask import jsonify
from collections import Counter

app = Flask(__name__) # See this website to get an explanation of what flask does -> https://pythonhow.com/how-a-flask-app-works/


@app.route('/')
def hello():
    # Flask will look for templates in the templates folder. So if your application is a module, this folder is next to that module, if it’s a package it’s actually inside your package:
    return render_template('index.html')

# This creates a flask web app on the /results page.
@app.route('/result')
def result():
    results = pd.read_csv('test_set.csv', skiprows=[1,2])
    results = results.replace(np.nan, '', regex=True)
    #print(results[['feedbackMDA','feedbackDMH']])
    results['feedback'] = results[['feedbackMDA','feedbackDMH']].apply(lambda x: ''.join(x), axis=1)
    names = results['feedback'].unique()
    group = 'MDA'
    Filtered_group = 'feedback'+group
    Feedback_group = 'division'+group
    names = results[Filtered_group].unique()
    print(results.columns)
    scoring = []
    for name in names[1:10]:
        if len(results[results['feedback']==name]) > 2:
            name1 = {}
            #print(name+":"+str(len(results[results['feedback']==name])))
            name1['name'] = name

            division = results[Feedback_group][results['feedback']==name].iloc[0]
            name1['division'] = division
        
            department = results['department'][results['feedback']==name].iloc[0]
            name1['department'] = department
        
            role = results['role'+group][results['feedback']==name].iloc[0]
            name1['role'] = role
        
            facility = results['facility'+group][results['feedback']==name].iloc[0]
            name1['facility'] = facility
        
            shift = results['shift'][results['feedback']==name].iloc[0]
            name1['shift'] = shift
        
            name1['countofresponse'] = results[results['feedback']==name].shape[0]
                
            score = results[['Core_Questions_1', 'Core_Questions_2',
           'Core_Questions_3', 'Core_Questions_4', 'Core_Questions_5',
           'Core_Questions_6']][results['feedback']==name]
            comments = results['comments'][results['feedback']==name]
            name1['comments']=(list(filter(None, comments.tolist())))
            overall = {'Sometimes': 0, 'Often': 0, 'Always': 0, 'Rarely': 0, 'Never': 0}
            for item in score.columns:
                try:
                    overall = Counter(score[item].value_counts().to_dict()) + Counter(overall)
                except:
                    overall = Counter(score[item].value_counts().to_dict())
                name1.update({str(item):score[item].value_counts(normalize=True).to_dict()})
            #print(overall)
            
            overall = dict(overall)
            name1['score'] = overall
            try:
                Always = overall['Always']
            except:
                Always = 0
            try:
                Often = overall['Often']
            except:
                Often = 0
            #print((Always+Often)/sum(overall.values()))
            name1['favScore'] = (Always+Often)/sum(overall.values())
            s = sum(overall.values())
            item_score ={}
            for k, v in overall.items():
                pct = v * 100.0 / s
                item_score[k] = pct
            #print(item_score)
            name1['item_score'] = item_score
            
            scoring.append(name1)

    print(scoring)
    return render_template('result.html', result = scoring)


@app.route('/<name>')
def hello_name(name):
    return "Hello {}!".format(name)

if __name__ == '__main__':
    """  https://github.com/r0x0r/pywebview/blob/master/examples/http_server.py
    """

    webbrowser.open_new("http://127.0.0.1:5000/result")
    app.run()
    #
    t = threading.Thread(target=start_server)
    t.daemon = True
    t.start()
