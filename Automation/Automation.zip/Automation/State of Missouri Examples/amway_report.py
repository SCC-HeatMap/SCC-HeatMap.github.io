import pandas as pd
import numpy as np
from flask import *
import webbrowser
import os
import requests
import simplejson as json
from flask import jsonify
from collections import Counter
import threading

app = Flask(__name__) # See this website to get an explanation of what flask does -> https://pythonhow.com/how-a-flask-app-works/

@app.route('/')
def hello():
    # Flask will look for templates in the templates folder. So if your application is a module, this folder is next to that module, if it’s a package it’s actually inside your package:
    return render_template('test.html')



# This creates a flask web app on the /results page.
@app.route('/result')
def result():
    results = pd.read_csv("C:\\Users\\willylee\\Desktop\\Projects\\SRC Automation\\State of Missouri Examples\\test_set.csv", skiprows=[1]) # Skips rows 2 since it is 0 indexed
    results = results.replace(np.nan, '', regex=True) # Replaces NaN with blanks

    # Concat Name columns
    results['feedback'] = results[['Feedback A-H', 'Feedback I - P', 'Feedback Q - Z', 'Q18', 'Q19', 'Q20','Q22','Q23','Q24','Q26','Q27','Q28','Q30','Q31','Q32']].apply(lambda x: ''.join(x), axis=1) # Concats these two columns into one. This gives you a full list of people that recieved feedback
    names = results["feedback"].unique() # creates a DF of unique people

    # Creates a python list named scoring that will hold all the data/stats we calculate for each person rated
    scoring = []

    # Goes through the names list if their name shows up more than 3 times than we run their stats through the analysis
    for name in names:
        if len(results[results['feedback'] == name]) > 3: #This function only runs the analysis if the person's name shows up 4 or more times
            name1 = {} # creates a dictionary data structure
            # print(name+":"+str(len(results[results['feedback']==name])))
            name1['feedback'] = name # Sets the dictionary token "name" and gives it the value stored in name

            # Split the emails from the text
            # Lowercase Proper case the emails
            # Strip the Names
            temp = name.split("(")
            temp[0] = temp[0].strip()
            temp[1] = temp[1].title()

            name1['name'] = temp[0]
            name1['email'] = temp[1][:-1]

            def get_long(comment):
                return len(comment) > 12

            market = results["Market/Function"][results['feedback'] == name].iloc[0] # This code looks for the market/function column; Then parses this down further by looking for the rows that have the name you are looking for; Finally, it take the division of the first value that matches
            name1['market'] = market # Sets the dictionary token "market" and gives it the value stored in the above variable

            name1['countofresponse'] = results[results['feedback'] == name].shape[0] # number of responses (rows) the person had

            comments1 = results['Q8'][results['feedback'] == name] # This saves the person's comments that they got
            name1['comments1'] = (list(filter(lambda comment: get_long(comment),comments1.tolist()))) # This filters the comments a person receives into a list then saves that list to the dictionary token "comments"

            comments2 = results['Q16'][results['feedback'] == name] # This saves the person's comments that they got
            name1['comments2'] = (list(filter(lambda comment: get_long(comment), comments2.tolist()))) # This filters the comments a person receives into a list then saves that list to the dictionary token "comments"

            comments3 = results['Q9'][results['feedback'] == name] # This saves the person's comments that they got
            name1['comments3'] = (list(filter(lambda comment: get_long(comment), comments3.tolist()))) # This filters the comments a person receives into a list then saves that list to the dictionary token "comments"


            def addCounters(self, other):
                if not isinstance(other, Counter):
                    return NotImplemented
                result = Counter()
                for elem, count in self.items():
                    newcount = count + other[elem]
                    result[elem] = newcount
                for elem, count in other.items():
                    if elem not in self:
                        result[elem] = count
                return result

            def div_d(my_dict):

                sum_p = sum(my_dict.values())

                for i in my_dict:
                    my_dict[i] = float(my_dict[i] / sum_p) * 100

                return my_dict

            temp = results['Q3'][results['feedback'] == name] # This saves the person's comments that they got
            likert1 = Counter({'Strongly Agree': 0, 'Agree': 0, 'Partially Agree': 0, 'Disagree': 0}) # Creates a dictionary named overall and gives it token: values.
            likert1 = addCounters(likert1, Counter(temp.value_counts().to_dict()))
            likert1 = dict(likert1)
            strongly = likert1['Strongly Agree']
            agree = likert1['Agree']
            name1['likert1'] = likert1
            name1['favScore1'] = ((strongly + agree) / sum(likert1.values())) * 100
            name1['likert1_p'] = div_d(likert1)

            temp = results['Q6'][results['feedback'] == name] # This saves the person's comments that they got
            likert2 = Counter({'Strongly Agree': 0, 'Agree': 0, 'Partially Agree': 0, 'Disagree': 0}) # Creates a dictionary named overall and gives it token: values.
            likert2 = addCounters(likert2, Counter(temp.value_counts().to_dict()))
            likert2 = dict(likert2)
            strongly = likert2['Strongly Agree']
            agree = likert2['Agree']
            name1['likert2'] = likert2
            name1['favScore2'] = ((strongly + agree) / sum(likert2.values())) * 100
            name1['likert2_p'] = div_d(likert2)

            temp = results['Q7'][results['feedback'] == name] # This saves the person's comments that they got
            likert3 = Counter({'Strongly Agree': 0, 'Agree': 0, 'Partially Agree': 0, 'Disagree': 0}) # Creates a dictionary named overall and gives it token: values.
            likert3 = addCounters(likert3, Counter(temp.value_counts().to_dict()))
            likert3 = dict(likert3)
            strongly = likert3['Strongly Agree']
            agree = likert3['Agree']
            name1['likert3'] = likert3
            name1['favScore3'] = ((strongly + agree) / sum(likert3.values())) * 100
            name1['likert3_p'] = div_d(likert3)


            temp = results['Q4'][results['feedback'] == name] # This saves the person's comments that they got
            mindset1 = Counter({'Share Openly and Directly': 0, 'Include': 0, "Think \"we before me\"": 0, 'Obsess over ABO Success': 0, 'Amplify the Customer Experience': 0, 'Unleash our Inner Entrepreneur': 0, 'Purpose our Passions': 0, 'Explore New Paths': 0, 'Model Grit and Resilience': 0}) # Creates a dictionary named overall and gives it token: values.
            mindset1 = addCounters(mindset1, Counter(temp.value_counts().to_dict()))
            name1['mindset1'] = dict(mindset1)

            temp = results['Q5'][results['feedback'] == name] # This saves the person's comments that they got
            mindset2 = Counter({'Share Openly and Directly': 0, 'Include': 0, "Think \"we before me\"": 0, 'Obsess over ABO Success': 0, 'Amplify the Customer Experience': 0, 'Unleash our Inner Entrepreneur': 0, 'Purpose our Passions': 0, 'Explore New Paths': 0, 'Model Grit and Resilience': 0}) # Creates a dictionary named overall and gives it token: values.
            mindset2 = addCounters(mindset2, Counter(temp.value_counts().to_dict()))
            name1['mindset2'] = dict(mindset2)


            scoring.append(name1) #Adds everything we just did the specific person to the scoring list before moving onto the next person in the loop


    return render_template('result3.html', result=scoring)


if __name__ == '__main__':
    webbrowser.open_new("http://127.0.0.1:5000/result")
    app.run()

