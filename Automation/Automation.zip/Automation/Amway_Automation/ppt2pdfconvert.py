import sys  
import os  
import glob  
import win32com.client
import ast

from os import listdir
from os.path import isfile, join
mypath = r"C:\\Users\\willylee\\Desktop\\Projects\\SRC Automation\\Amway_Automation\\report"
onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
print(onlyfiles)

for filex in onlyfiles:
    location = os.path.join(mypath, filex)
    location = "r'"+str(location)+"'"
    def convert(files, formatType = 32):  
        powerpoint = win32com.client.Dispatch("Powerpoint.Application")  
        powerpoint.Visible = 1  
        for filename in files:  
            newname = os.path.splitext(filename)[0] + ".pdf"  
            deck = powerpoint.Presentations.Open(filename)  
            deck.SaveAs(newname, formatType)  
            deck.Close()  
            powerpoint.Quit()  

    files = glob.glob(ast.literal_eval(location))  
    convert(files)