Quick_Guide.md

## Packages:
pandas -> Data munging package 
numpy -> Tools for woring with numbers
flask -> Web framework and web application laumcher
webbrowser -> Allows you to interact with urls and web browsers in python
os -> tools for operating system operators
request -> tools to make web requests
simplejson  -> Expands the tools that JSON has. See example below:
from flask import jsonify

@app.route('/_get_current_user')
def get_current_user():
    return jsonify(username=g.user.username,
                   email=g.user.email,
                   id=g.user.id)

Returns the following:
{
    "username": "admin",
    "email": "admin@localhost",
    "id": 42
}

flask|jsonify -> Allows you to create JSON data sctructures
collections|counter -> A Counter is a container that keeps track of how many times equivalent values are added. See examples below for how to use this:
print collections.Counter(['a', 'b', 'c', 'a', 'b', 'b'])
print collections.Counter({'a':2, 'b':3, 'c':1})
print collections.Counter(a=2, b=3, c=1)


## Downloading Packages:
#### Use the following code below to get all the required packages to run this program. You will need to insert the path to your requirements directory. Mine is also listed below for reference

TEMPLATE:
pip install -r </path/to/requirements.txt>

MY EXAMPLE:
pip install -r </path/to/requirements.txt>


## Code Quick Tips:














